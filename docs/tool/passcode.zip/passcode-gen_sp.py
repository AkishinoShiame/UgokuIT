#!/usr/bin/python3
import os
import time
while(1):
    os.system('clear')
    import passcodegen as pg
    print("Normal PASS: ")
    for i in range(10):
        print("  Line", i ,":", end='')
        pg.gen_normal()
    print("Best PASSWORD: ")
    for i in range(10):
        print("  Line", i ,":", end='')
        pg.nice_rand()
    print("Free Style: ")
    for i in range(10):
        print("  Line", i ,":", end='')
        pg.rando_pass()
    time.sleep(0.07)
