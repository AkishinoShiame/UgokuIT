#!/usr/bin/python3
import random as rand

Beng = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
Seng = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
Num = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
Spec = [ '!', '%', '&', "'", '(', ')', '.', '_', ':', ';' ]

Total_lst = Beng + Seng + Num + Spec

def gen_normal():
    print(Beng[rand.randrange(0,len(Beng))], end='')
    for i in range(5):
        print(Seng[rand.randrange(0,len(Seng))], end='')
    for i in range(4):
        print(Num[rand.randrange(0,len(Num))], end='')
    for i in range(2):
        print(Spec[rand.randrange(0,len(Spec))], end='')
    print()

def nice_rand():
    # print('"', end='')
    rsed=[0,0,0,0,0,0,0]
    rsed[0] = rand.randint(0,11)
    while(True):
        tmp = rand.randint(0,11)
        if(tmp != rsed[0]):
            rsed[1] = tmp
            break
    while(True):
        tmp = rand.randint(0,11)
        if(tmp != rsed[0] and tmp != rsed[1]):
            rsed[2] = tmp
            break
    while(True):
        tmp = rand.randint(0,11)
        if(tmp != rsed[0] and tmp != rsed[1] and tmp != rsed[2]):
            rsed[3] = tmp
            break
    while(True):
        tmp = rand.randint(0,11)
        if(tmp != rsed[0] and tmp != rsed[1] and tmp != rsed[2] and tmp != rsed[3]):
            rsed[4] = tmp
            break
    while(True):
        tmp = rand.randint(0,11)
        if(tmp != rsed[0] and tmp != rsed[1] and tmp != rsed[2] and tmp != rsed[3] and tmp != rsed[4]):
            rsed[5] = tmp
            break
    while(True):
        tmp = rand.randint(0,11)
        if(tmp != rsed[0] and tmp != rsed[1] and tmp != rsed[2] and tmp != rsed[3] and tmp != rsed[4] and tmp != rsed[5]):
            rsed[6] = tmp
            break
    for i in range(12):
        if(i==rsed[0]):
            print(Beng[rand.randrange(0,len(Beng))], end='')
        elif(i==rsed[1]):
            print(Spec[rand.randrange(0,len(Spec))], end='')
        elif(i==rsed[2]):
            print(Spec[rand.randrange(0,len(Spec))], end='')
        elif(i==rsed[3]):
            print(Num[rand.randrange(0,len(Num))], end='')
        elif(i==rsed[4]):
            print(Num[rand.randrange(0,len(Num))], end='')
        elif(i==rsed[5]):
            print(Num[rand.randrange(0,len(Num))], end='')
        elif(i==rsed[6]):
            print(Num[rand.randrange(0,len(Num))], end='')
        else:
            print(Seng[rand.randrange(0,len(Seng))], end='')
    print()
    # print('"')
# print(Beng[rand.randrange(0,len(Beng))])
# print(Seng[rand.randrange(0,len(Seng))])
# print(Spec[rand.randrange(0,len(Spec))])
def rando_pass():
    #print("Free Style: ",end='')
    for i in range(12):
        print(Total_lst[rand.randrange(0,len(Total_lst))], end='')
    print()

if(__name__=='__main__'):
    print("Normal PASS: ")
    for i in range(10):
        print("  Line", i ,":", end='')
        gen_normal()
    print("Best PASSWORD: ")
    for i in range(10):
        print("  Line", i ,":", end='')
        nice_rand()
    print("Free Style: ")
    for i in range(10):
        print("  Line", i ,":", end='')
        rando_pass()
